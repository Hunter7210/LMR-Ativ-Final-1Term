# LMRFinal; APRESENTAÇÃO/ENTREGA DIA 16/06/23

FAZER SITE DE VENDA DE INGRESSOS
============================================
HTML
CSS
JAVASCRIPT
==============================================
SITE COMPLETO (Várias abas)
==========================================================
APRESENTAÇÃO:
Seguir os Pontos criticos.
Apresentados no doc.
Foco em explicar o CÓD.
================================================= 
PAGINA DE CADASTRO DE EVENTOS:

Pagina de login
PAGINA DE CADASTRO de Usuario
Gerador de CARD, (TENTAR QRCODE)

